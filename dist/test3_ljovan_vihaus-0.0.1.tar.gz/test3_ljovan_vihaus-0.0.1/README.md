# Tweet Processor Vihaus Ljovan

Tweet processor is a small program that does some NLP-magick on tweet-strings.
It comes with a cli-interface on which the language (english or spanish)can be chosen,
as well as the kinds of modifications to the original string (tokenisation,
hiding URLs, hiding @-mentions etc.).
